#include <iostream>
#include <sstream>
#include <time.h>
#include "utf8.h"

using namespace std;
int main()
{
//  utf8 u2[] = {utf8(0xe6, 0xb3, 0x95), utf8(0xe6, 0x94, 0xbf), utf8(0xe5, 0xa4, 0xa7), utf8(0xe5, 0xad, 0xa6)};
//  utf8 u3[4];
//  utf8 u4;
//  utf8 u5[10];
//
//  // show utf-8 character
//  for(int i = 0; i < 4; i++)
//  {
//    cout << i << " : " << u2[i] << endl;
//  }
//
//  string s("法政大学");
//  int offset = 0;
//  const char* sp = s.c_str();
//  for (int i = 0; i < 4; i++)
//  {
//    u3[i] = utf8(sp+offset);
//    offset += u3[i].countBytes();
//    cout << u3[i] << '/';
//  }
//  cout << endl;

  utf8 uc = utf8(0xe6, 0xb3, 0x95);

  const int loopend = 100000;
  clock_t start = clock();
  for (int i = 0; i < loopend; i++) {}
  clock_t end = clock();
  cout << "time : for" << (double)(end - start) << endl;

  clock_t t1 = clock();
  for (int i = 0; i < loopend; i++)
  {
    uc.countBytes();
  }
  clock_t t2 = clock();

  clock_t t3 = clock();
  for (int i = 0; i < loopend; i++)
  {
    uc.countBytes31();
  }
  clock_t t4 = clock();

  cout << "clock diff13 : " << (double)(t2 - t1) - (double)(end - start) << endl;
  cout << "clock diff31 : " << (double)(t4 - t3) - (double)(end - start) << endl;
}
